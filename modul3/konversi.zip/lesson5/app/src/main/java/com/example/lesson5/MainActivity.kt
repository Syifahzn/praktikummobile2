package com.example.lesson5

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.lesson5.databinding.ActivityMainBinding
import java.text.NumberFormat

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.konversiButton.setOnClickListener { konversi() }
    }

    @SuppressLint("StringFormatInvalid", "StringFormatMatches")
    private fun konversi(){
        val stringInTextField = binding.editText.text.toString()
        val uang = stringInTextField.toDoubleOrNull()
        if (uang == null){
            binding.textView2.text = ""
        }

        val konversiUang = when (binding.optionMataUang.checkedRadioButtonId) {
            R.id.option_Euro -> 15657.76
            R.id.option_USDollar -> 14354.50
            R.id.option_japanese_yen -> 114.51
            else -> 3825.42
        }
        var tip = konversiUang * uang!!

        val formattedkonversi = NumberFormat.getCurrencyInstance().format(tip)
        binding.textView2.text = getString(R.string.nilai_rupiah, formattedkonversi)
    }
}